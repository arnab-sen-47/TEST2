# File Size Checker Plugin

Plugin developed for Kaiser Permanente

Checks every file in a directory against a threshold.

Example input: 

`/home/david:0:eq`

Checks every file size inside `/home/david`, if any of them is equal to 0, creates an alert.


Possible operators:

`gt, lt, gte, lte, eq`