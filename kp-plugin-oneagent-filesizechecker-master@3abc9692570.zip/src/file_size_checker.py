import os


class File:
    def __init__(self, name: str, size: int):
        self.name = name
        self.size = size

    def __str__(self):
        return f'File "{self.name}" size is {self.size} bytes'

    def __lt__(self, other):
        return self.size < other.size


operations = {
    'gt': lambda file_size, threshold: file_size > threshold,
    'gte': lambda file_size, threshold: file_size >= threshold,
    'lt': lambda file_size, threshold: file_size < threshold,
    'lte': lambda file_size, threshold: file_size <= threshold,
    'eq': lambda file_size, threshold: file_size == threshold,
}


def check_files(directory: str):
    files = [os.path.join(directory, f) for f in os.listdir(directory) if os.path.isfile(os.path.join(directory, f))]

    for file in files:
        size = os.stat(file).st_size
        yield File(file, size)


def main():
    for f in check_files('/home/david'):
        print(f)


if __name__ == '__main__':
    main()
