import logging
import time

from file_size_checker import check_files

from ruxit.api.base_plugin import BasePlugin
from ruxit.api.selectors import HostSelector
from ruxit.api.data import PluginMeasurement

from croniter import croniter
from datetime import datetime as dt


logger = logging.getLogger(__name__)


class KPCheckFileSize(BasePlugin):
    def query(self, **kwargs):
        config = kwargs["config"]

        description = config.get("description", "")

        run = True
        if "schedule" in kwargs["config"] and kwargs["config"]["schedule"]:
            run = False
            schedule = kwargs["config"]["schedule"]
            now = dt.now()
            cron = croniter(schedule, now)

            previous = cron.get_prev(ret_type=dt)

            logger.info(
                f"kp_check_file_size - Time now is {now}, Previous cron execution is {previous}"
            )

            minutes_from_prev = (
                time.mktime(now.timetuple()) - time.mktime(previous.timetuple())
            ) / 60

            logger.info(
                f"kp_check_file_size - Time difference from previous: {minutes_from_prev} minutes"
            )

            if minutes_from_prev < 1:
                run = True

        if run:
            for directory in config["input"].split(","):
                for f in sorted(list(check_files(directory))[:10], reverse=True):
                    measurement = PluginMeasurement(
                        "file_size",
                        f.size,
                        dimensions={"FileName": f.name},
                        entity_selector=HostSelector(),
                    )
                    self.results_builder.add_absolute_result(measurement)
